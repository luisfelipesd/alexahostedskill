EMPLOYEES = {
    "abraham acrich": {
        "Teléfono": "264-5111",
        "email": "abraham@gruporesidencial.com",
        "Extensión": "173",
        "Titulo": "Director Comercial"
    },
    "adolfo noriega": {
        "Teléfono": "264-5111",
        "email": "adolfo@gruporesidencial.com",
        "Extensión": "129",
        "Titulo": "Director de proyectos residenciales"
    },
    "ailyn cañizalez": {
        "Teléfono": "264-5111",
        "email": "ailyn@gruporesidencial.com",
        "Extensión": "149",
        "Titulo": "Auxiliar Contable"
    },
    "alejandro sosa": {
        "Teléfono": "264-5111/201-3399",
        "email": "alejandro@gruporesidencial.com",
        "Extensión": "152/200",
        "Titulo": "Gerente de Proyecto"
    },
    "alina hidalgo": {
        "Teléfono": "264-5111",
        "email": "ahidalgo@gruporesidencial.com",
        "Extensión": "108",
        "Titulo": "Asistente Legal"
    },
    "alina tuñón": {
        "Teléfono": "264-5111",
        "email": "atdelvalle@gruporesidencial.com",
        "Extensión": "122",
        "Titulo": "Asist. Admin. Trámites Legal"
    },
    "amílcar olaciregui": {
        "Teléfono": "264-5111",
        "email": "mensajeria@gruporesidencial.com",
        "Extensión": "101",
        "Titulo": "Mensajería"
    },
    "ana melinda sosa": {
        "Teléfono": "264-5111",
        "email": "anasosa@gruporesidencial.com",
        "Extensión": "123",
        "Titulo": "Gerente de Arquitectura"
    },
    "ana chen": {
        "Teléfono": "201-3399",
        "email": "planillapdn@gruporesidencial.com",
        "Extensión": "202",
        "Titulo": "Asistente de Planilla"
    },
    "andreina rodríguez": {
        "Teléfono": "264-5111",
        "email": "andreina@gruporesidencial.com",
        "Extensión": "143",
        "Titulo": "Community Manager"
    },
    "andrés sosa": {
        "Teléfono": "264-5111/201-3399",
        "email": "andres@gruporesidencial.com",
        "Extensión": "161/228",
        "Titulo": "Gerente de Infraestructura"
    },
    "anette barahona": {
        "Teléfono": "264-5111",
        "email": "anette@gruporesidencial.com",
        "Extensión": "103",
        "Titulo": "Asistente Ejecutiva"
    },
    "angela gonzalez": {
        "Teléfono": "",
        "email": "",
        "Extensión": "",
        "Titulo": "Limpieza"
    },
    "angelys rodríguez": {
        "Teléfono": "201-3399",
        "email": "angelys@gruporesidencial.com",
        "Extensión": "",
        "Titulo": "Inspector"
    },
    "boris villarreal": {
        "Teléfono": "2019927",
        "email": "",
        "Extensión": "",
        "Titulo": "Asist. Admin. Campo"
    },
    "caralay mesa": {
        "Teléfono": "2645111",
        "email": "recepciongr@gruporesidencial.com",
        "Extensión": "101",
        "Titulo": "Recepcionista"
    },
    "carlos moses arango": {
        "Teléfono": "264-5111",
        "email": "cmoses@gruporesidencial.com",
        "Extensión": "133",
        "Titulo": "Gerente General"
    },
    "carol phillips": {
        "Teléfono": "246-2299",
        "email": "sisobga@gruporesidencial.com",
        "Extensión": "",
        "Titulo": "Inspector SISO"
    },
    "carolina velandia": {
        "Teléfono": "264-5111",
        "email": "cvelandia@gruporesidencial.com",
        "Extensión": "150",
        "Titulo": "Gerente de Post Venta"
    },
    "cecibel martez": {
        "Teléfono": "2645111",
        "email": "cecibel@gruporesidencial.com",
        "Extensión": "101",
        "Titulo": "Ejecutivo de Ventas"
    },
    "cecilia schmidt": {
        "Teléfono": "264-5111",
        "email": "cschmidt@gruporesidencial.com",
        "Extensión": "141",
        "Titulo": "Gerente de Propiedades de Inversión"
    },
    "claudia cardona": {
        "Teléfono": "201-3399",
        "email": "claudia@gruporesidencial.com",
        "Extensión": "208",
        "Titulo": "Coordinación Laboral"
    },
    "cristhian hualde": {
        "Teléfono": "",
        "email": "chualde@gruporesidencial.com",
        "Extensión": "",
        "Titulo": "Gerente de Logistica"
    },
    "daliana bonilla": {
        "Teléfono": "264-5111",
        "email": "daliana@gruporesidencial.com",
        "Extensión": "158",
        "Titulo": "Asist. Admin. Trámites Legal"
    },
    "dana ulloa": {
        "Teléfono": "264-5111",
        "email": "dana@gruporesidencial.com",
        "Extensión": "128",
        "Titulo": "Asist. Admin. Contabilidad"
    },
    "darlene granizo": {
        "Teléfono": "246-2299",
        "email": "dgranizo@gruporesidencial.com",
        "Extensión": "303",
        "Titulo": "Asist. Admin. Campo"
    },
    "dayana campo": {
        "Teléfono": "264-5111",
        "email": "dayana@gruporesidencial.com",
        "Extensión": "168",
        "Titulo": "Gerente de Ventas BGA"
    },
    "diana newball": {
        "Teléfono": "2645111",
        "email": "dnewball@gruporesidencial.com",
        "Extensión": "101",
        "Titulo": "Inspector de Obra"
    },
    "edgar garcia": {
        "Teléfono": "201-3399",
        "email": "egarcia@gruporesidencial.com",
        "Extensión": "299",
        "Titulo": "Inspector Electrico"
    },
    "edgar hilbert": {
        "Teléfono": "2645111",
        "email": "ehilbert@gruporesidencial.com",
        "Extensión": "177",
        "Titulo": "Gerente de Finanzas"
    },
    "edgar tuñon": {
        "Teléfono": "201-3399",
        "email": "etunon@gruporesidencial.com",
        "Extensión": "231",
        "Titulo": "Topografía"
    },
    "edgardo ortega": {
        "Teléfono": "264-5111",
        "email": "eortega@gruporesidencial.com",
        "Extensión": "170",
        "Titulo": "Analista de Soporte Técnico"
    },
    "edgardo payares": {
        "Teléfono": "2010-3399",
        "email": "edgardo@gruporesidencial.com",
        "Extensión": "234",
        "Titulo": "Gerente de RRHH"
    },
    "ediodexi pérez": {
        "Teléfono": "264-5111",
        "email": "mensajeria@gruporesidencial.com",
        "Extensión": "101",
        "Titulo": "Mensajería"
    },
    "edison batista": {
        "Teléfono": "2645111",
        "email": "ebatista@gruporesidencial.com",
        "Extensión": "124",
        "Titulo": "Ing. de diseño, infraestructura y urbanismo"
    },
    "eduardo chen": {
        "Teléfono": "201-3399",
        "email": "echen@gruporesidencial.com",
        "Extensión": "206",
        "Titulo": "Inspector SISO"
    },
    "emyleidys lópez": {
        "Teléfono": "264-5111",
        "email": "emyleidys@gruporesidencial.com",
        "Extensión": "113",
        "Titulo": "Asist. Admin. Trámites Legal"
    },
    "enderson molina": {
        "Teléfono": "246-2299",
        "email": "emolina@gruporesidencial.com",
        "Extensión": "399",
        "Titulo": "Superintendente de Infraestructura"
    },
    "eybar alvarado": {
        "Teléfono": "201-3399",
        "email": "eybar@gruporesidencial.com",
        "Extensión": "231",
        "Titulo": "Jefe de Topografía"
    },
    "fany francis": {
        "Teléfono": "2645111",
        "email": "fany@gruporesidencial.com",
        "Extensión": "101",
        "Titulo": "Ejecutiva de Ventas"
    },
    "federico blackman": {
        "Teléfono": "264-5111",
        "email": "federico@gruporesidencial.com",
        "Extensión": "119",
        "Titulo": "Gerente de Contabilidad"
    },
    "fernando sosa": {
        "Teléfono": "264-5111",
        "email": "fernando@gruporesidencial.com",
        "Extensión": "109",
        "Titulo": "Director de Proyectos Residenciales"
    },
    "francisco barrios": {
        "Teléfono": "264-5111",
        "email": "francisco@gruporesidencial.com",
        "Extensión": "142",
        "Titulo": "Gerente de Mercadeo"
    },
    "giulio aicardi": {
        "Teléfono": "264-5111",
        "email": "giulio@gruporesidencial.com",
        "Extensión": "178",
        "Titulo": "Arquitecto Diseñador"
    },
    "gloria castillero": {
        "Teléfono": "2645111",
        "email": "gcastillero@gruporesidencial.com",
        "Extensión": "174",
        "Titulo": "Asistente Ejecutiva"
    },
    "graciela zapata": {
        "Teléfono": "201-3399",
        "email": "gzapata@gruporesidencial.com",
        "Extensión": "226",
        "Titulo": "Administrador de Flota"
    },
    "guillermo aguilar": {
        "Teléfono": "201-3399",
        "email": "guillermo@gruporesidencial.com",
        "Extensión": "214",
        "Titulo": "Asist. Admin. Campo"
    },
    "guillermo silvera": {
        "Teléfono": "264-5111",
        "email": "g.silvera@gruporesidencial.com",
        "Extensión": "114",
        "Titulo": "Gerente de Presupuesto"
    },
    "hilary carrera": {
        "Teléfono": "264-5111",
        "email": "hilary@gruporesidencial.com",
        "Extensión": "137",
        "Titulo": "Asist. Admin. Planilla"
    },
    "ibeth segundo": {
        "Teléfono": "201-3399",
        "email": "ibeth@gruporesidencial.com",
        "Extensión": "211",
        "Titulo": "Superintendente de Infraestructura"
    },
    "iliana santamaría": {
        "Teléfono": "264-5111",
        "email": "iliana@gruporesidencial.com",
        "Extensión": "140",
        "Titulo": "Oficial de Cumplimiento"
    },
    "isaac racines": {
        "Teléfono": "264-5111",
        "email": "iracines@gruporesidencial.com",
        "Extensión": "171",
        "Titulo": "Asistente de Soporte Técnico"
    },
    "isabel abrego": {
        "Teléfono": "",
        "email": "isabel@gruporesidencial.com",
        "Extensión": "",
        "Titulo": "Ejecutiva de ventas"
    },
    "ivan fernandez": {
        "Teléfono": "264-5111",
        "email": "mensajeria@gruporesidencial.com",
        "Extensión": "157",
        "Titulo": "Ayudante General"
    },
    "jan felipe tapia": {
        "Teléfono": "264-5111",
        "email": "jtapia@gruporesidencial.com",
        "Extensión": "120",
        "Titulo": "Director de Proyectos Especiales"
    },
    "javier caballero": {
        "Teléfono": "2645111",
        "email": "jcaballero@gruporesidencial.com",
        "Extensión": "299",
        "Titulo": "Recepcionista Campamento PDN"
    },
    "jazmin velasco": {
        "Teléfono": "2645111",
        "email": "jazmin@gruporesidencial.com",
        "Extensión": "106",
        "Titulo": "Gerente de Legal"
    },
    "jeany barragán": {
        "Teléfono": "264-5111",
        "email": "jeany@gruporesidencial.com",
        "Extensión": "125",
        "Titulo": "Asist. Admin. Trámites Legal"
    },
    "jelenis vergara": {
        "Teléfono": "2645111",
        "email": "jvergara@gruporesidencial.com",
        "Extensión": "100",
        "Titulo": "Auxiliar de Auditoria"
    },
    "jennifer sánchez": {
        "Teléfono": "830-3047",
        "email": "recepcionbga@gruporesidencial.com",
        "Extensión": "",
        "Titulo": "Asist. Admin. Campo"
    },
    "jhonny jiménez": {
        "Teléfono": "246-2299",
        "email": "jjimenez@gruporesidencial.com",
        "Extensión": "399",
        "Titulo": "Inspector"
    },
    "jhonny oliveros": {
        "Teléfono": "2013399",
        "email": "joliveros@gruporesidencial.com",
        "Extensión": "213",
        "Titulo": "Digitador"
    },
    "joel peréz": {
        "Teléfono": "836-6645 / 46",
        "email": "joel@gruporesidencial.com",
        "Extensión": "215",
        "Titulo": "Asist. Admin. Campo"
    },
    "jose herrera": {
        "Teléfono": "246-2299",
        "email": "jherrera@gruporesidencial.com",
        "Extensión": "301",
        "Titulo": "Gerente de Proyecto BGA"
    },
    "josé zuñiga": {
        "Teléfono": "264-5111",
        "email": "jzuniga@gruporesidencial.com",
        "Extensión": "112",
        "Titulo": "Gerente de Auditoría y Edos. Financieros"
    },
    "josé a. sosa": {
        "Teléfono": "264-5111",
        "email": "jose@gruporesidencial.com",
        "Extensión": "102",
        "Titulo": "Gerente General"
    },
    "josé manuel adames": {
        "Teléfono": "202-4440",
        "email": "jadames@gruporesidencial.com",
        "Extensión": "205",
        "Titulo": "Superintendente de Proyecto"
    },
    "juan carlos camargo": {
        "Teléfono": "836-6645 / 46",
        "email": "jcamargo@gruporesidencial.com",
        "Extensión": "205",
        "Titulo": "Jefe de electrificación y telecomunicaciones"
    },
    "karin velasquez": {
        "Teléfono": "264-5111 / 202-4440",
        "email": "karin@gruporesidencial.com",
        "Extensión": "121 / 402",
        "Titulo": "Gerente de Ventas PDN"
    },
    "karina gonzalez": {
        "Teléfono": "202-4440",
        "email": "karina@gruporesidencial.com",
        "Extensión": "401",
        "Titulo": "Ejecutiva de Ventas"
    },
    "katerin hernandez": {
        "Teléfono": "2024040",
        "email": "katerin@gruporesidencial.com",
        "Extensión": "401",
        "Titulo": "Ejecutiva de Ventas"
    },
    "katherine bonilla": {
        "Teléfono": "264-5111",
        "email": "katherine@gruporesidencial.com",
        "Extensión": "134",
        "Titulo": "Asist. Admin. Trámites Legal"
    },
    "laura coburn": {
        "Teléfono": "2645111",
        "email": "lcoburn@gruporesidencial.com",
        "Extensión": "131",
        "Titulo": "Gerente de Proyectos Especiales"
    },
    "leodanis rodriguez": {
        "Teléfono": "2645111",
        "email": "lrodriguez@gruporesidencial.com",
        "Extensión": "155",
        "Titulo": "Desarrollador de Planos"
    },
    "loideth sanchez": {
        "Teléfono": "264-5111",
        "email": "loideth@gruporesidencial.com",
        "Extensión": "148",
        "Titulo": "Asist. Admin. Planilla"
    },
    "luilly de leon": {
        "Teléfono": "264-5111",
        "email": "luilly@gruporesidencial.com",
        "Extensión": "156",
        "Titulo": "Desarrollador de Planos"
    },
    "luis arauz": {
        "Teléfono": "264-5111",
        "email": "larauz@gruporesidencial.com",
        "Extensión": "172",
        "Titulo": "Coordinador Administrativo"
    },
    "luis caceres": {
        "Teléfono": "201-3399",
        "email": "caceresl@gruporesidencial.com",
        "Extensión": "201",
        "Titulo": "Oficial de Postventa"
    },
    "luis carlos ortega": {
        "Teléfono": "264-5111",
        "email": "mensajeria@gruporesidencial.com",
        "Extensión": "",
        "Titulo": "Mensajería"
    },
    "luis saldaña": {
        "Teléfono": "264-5111",
        "email": "luisfelipe@gruporesidencial.com",
        "Extensión": "105",
        "Titulo": "Gerente de Tecnología"
    },
    "luz marina concepción": {
        "Teléfono": "264-5111",
        "email": "luz@gruporesidencial.com",
        "Extensión": "107",
        "Titulo": "Asist. Admin. Trámites Legal"
    },
    "manuel gonzález": {
        "Teléfono": "2645111",
        "email": "manuel@gruporesidencial.com",
        "Extensión": "101",
        "Titulo": "Ejecutivo de Ventas"
    },
    "marcos cardoza": {
        "Teléfono": "264-5111",
        "email": "mcardoza@gruporesidencial.com",
        "Extensión": "154",
        "Titulo": "Desarrollador de Planos"
    },
    "margarett murillo": {
        "Teléfono": "2645111",
        "email": "mmurillo@gruporesidencial.com",
        "Extensión": "167",
        "Titulo": "Asist. Admin. Trámites Legal"
    },
    "maría alexandra corrales": {
        "Teléfono": "2645111",
        "email": "mcorrales@gruporesidencial.com",
        "Extensión": "163",
        "Titulo": "Asistente Ejecutiva"
    },
    "mariela jiménez": {
        "Teléfono": "264-5111",
        "email": "mjimenez@gruporesidencial.com",
        "Extensión": "164",
        "Titulo": "Asistente Ejecutiva"
    },
    "mario gordon": {
        "Teléfono": "",
        "email": "mgordon@gruporesidencial.com",
        "Extensión": "",
        "Titulo": "Inspector de Infraestructura"
    },
    "mayky cruz": {
        "Teléfono": "8303047",
        "email": "mayky@gruporesidencial.com",
        "Extensión": "399",
        "Titulo": "Asist. Admin. Campo"
    },
    "mery elizabeth garay": {
        "Teléfono": "202-4440",
        "email": "mery@gruporesidencial.com",
        "Extensión": "401",
        "Titulo": "Ejecutivo de Ventas"
    },
    "michael cosaraquis": {
        "Teléfono": "201-3399",
        "email": "mcosaraquis@gruporesidencial.com",
        "Extensión": "233",
        "Titulo": "Encargado de Proyecto"
    },
    "michella pezzotti": {
        "Teléfono": "264-5111/201-3399",
        "email": "michella@gruporesidencial.com",
        "Extensión": "138/212",
        "Titulo": "Gerente de Bodegas e Inventario"
    },
    "michelle maquen": {
        "Teléfono": "202-4440",
        "email": "michelle@gruporesidencial.com",
        "Extensión": "400",
        "Titulo": "Recepcionista"
    },
    "miledys perez": {
        "Teléfono": "836-6645 / 46",
        "email": "miledys@gruporesidencial.com",
        "Extensión": "210",
        "Titulo": "Coordinadora de Proyectos"
    },
    "milvia rodriguez": {
        "Teléfono": "201-3399",
        "email": "mrodriguez@gruporesidencial.com",
        "Extensión": "230",
        "Titulo": "Asist. Admin. Campo"
    },
    "nayaris morales": {
        "Teléfono": "3685039",
        "email": "nmorales@gruporesidencial.com",
        "Extensión": "139",
        "Titulo": "Gerente de desarrollo organizacional"
    },
    "nelson von chong": {
        "Teléfono": "8317694",
        "email": "nvonchong@gruporesidencial.com",
        "Extensión": "230",
        "Titulo": "Supervisor de Operadores"
    },
    "olga salinas": {
        "Teléfono": "264-5111",
        "email": "olga@gruporesidencial.com",
        "Extensión": "144",
        "Titulo": "Asist. Admin. Cobros"
    },
    "omaira gonzalez": {
        "Teléfono": "2645111",
        "email": "omaira@gruporesidencial.com",
        "Extensión": "117",
        "Titulo": "Asist. Admin. Trámites Legal"
    },
    "pablo falcón": {
        "Teléfono": "836-6645 / 46",
        "email": "pablo@gruporesidencial.com",
        "Extensión": "204",
        "Titulo": "Coordinador de SISO"
    },
    "ramón noriega": {
        "Teléfono": "264-5111",
        "email": "ramon@gruporesidencial.com",
        "Extensión": "118",
        "Titulo": "Arquitecto Diseñador"
    },
    "raúl arango": {
        "Teléfono": "264-5111",
        "email": "raularango@gruporesidencial.com",
        "Extensión": "179",
        "Titulo": "Director de Administración y Finanzas"
    },
    "raúl diez": {
        "Teléfono": "264-5111",
        "email": "red@gruporesidencial.com",
        "Extensión": "116",
        "Titulo": "Director de Arquitectura"
    },
    "ricaurte obaldía": {
        "Teléfono": "264-5111",
        "email": "ricaurte@gruporesidencial.com",
        "Extensión": "110",
        "Titulo": "Supervisor de Planilla"
    },
    "roberto caballero": {
        "Teléfono": "8366645 / 46",
        "email": "roberto@gruporesidencial.com",
        "Extensión": "207",
        "Titulo": "Superintendente de Proyecto"
    },
    "roberto ward": {
        "Teléfono": "2645111",
        "email": "robertow@gruporesidencial.com",
        "Extensión": "101",
        "Titulo": "Mensajería"
    },
    "rubén herrera": {
        "Teléfono": "830-3047",
        "email": "rherrera@gruporesidencial.com",
        "Extensión": "301",
        "Titulo": "Superintendente de Proyecto"
    },
    "samuel arias": {
        "Teléfono": "264-5111",
        "email": "samuel@gruporesidencial.com",
        "Extensión": "165",
        "Titulo": "Analista de Proyecto"
    },
    "sandra avilés": {
        "Teléfono": "264-5111",
        "email": "saviles@gruporesidencial.com",
        "Extensión": "160",
        "Titulo": "Asist. Admin. Trámites Legal"
    },
    "stephanie cruz": {
        "Teléfono": "264-5111",
        "email": "stephanie@gruporesidencial.com",
        "Extensión": "115",
        "Titulo": "Asist. Admin. Contabilidad"
    },
    "yadira abrego": {
        "Teléfono": "264-5111",
        "email": "yadira@gruporesidencial.com",
        "Extensión": "126",
        "Titulo": "Asist. Admin. Trámites Legal"
    },
    "yamileth contreras": {
        "Teléfono": "2030892 / 93",
        "email": "ycontreras@gruporesidencial.com",
        "Extensión": "502",
        "Titulo": "Inspector Post Venta"
    },
    "yaneth domínguez": {
        "Teléfono": "",
        "email": "yaneth@gruporesidencial.com",
        "Extensión": "",
        "Titulo": "Asist. Admin. Post Venta"
    },
    "yanina espinosa": {
        "Teléfono": "830-3048",
        "email": "yespinosa@gruporesidencial.com",
        "Extensión": "306",
        "Titulo": "Encargada de Compras y Almacén BGA"
    },
    "yeraldin becerra": {
        "Teléfono": "836-6645 / 46",
        "email": "yeraldin@gruporesidencial.com",
        "Extensión": "202",
        "Titulo": "Asist. Admin. Campo"
    },
    "yessenia meneses": {
        "Teléfono": "",
        "email": " ymeneses@gruporesidencial.com",
        "Extensión": "225",
        "Titulo": "Inspector de Entrega"
    },
    "yessenia prado": {
        "Teléfono": "264-5111",
        "email": "yessenia@gruporesidencial.com",
        "Extensión": "127",
        "Titulo": "Jefe de Cobros"
    },
    "yessica romero": {
        "Teléfono": "264-5111",
        "email": "yromero@gruporesidencial.com",
        "Extensión": "130",
        "Titulo": "Analista de Desarrollo Organizacional"
    },
    "yireth candanedo": {
        "Teléfono": "201-3399",
        "email": "yireth@gruporesidencial.com",
        "Extensión": "201",
        "Titulo": "Coordinadora de Post Entrega"
    },
    "yovana mendez": {
        "Teléfono": "202-4440",
        "email": "",
        "Extensión": "400",
        "Titulo": "Limpieza - PDN"
    },
    "zurianny marciaga": {
        "Teléfono": "2645111",
        "email": "zmarciaga@gruporesidencial.com",
        "Extensión": "101",
        "Titulo": "Inspector de Obra"
    },
    "zyhara justiniani": {
        "Teléfono": "2645111",
        "email": "zjustiniani@gruporesidencial.com",
        "Extensión": "147",
        "Titulo": "Asistente Administrativa de Mercadeo"
    }
}