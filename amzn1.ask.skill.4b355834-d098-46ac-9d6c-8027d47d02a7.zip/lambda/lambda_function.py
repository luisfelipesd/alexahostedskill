import json
from ask_sdk_core.skill_builder import SkillBuilder
from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.dispatch_components import AbstractExceptionHandler
from ask_sdk_core.handler_input import HandlerInput
from ask_sdk_model import Response
from ask_sdk_core.utils import is_request_type, is_intent_name
from ask_sdk_model import Response
from ask_sdk_model.dialog import DelegateDirective
import employees

class LaunchRequestHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        print("Request object:", handler_input.request_envelope.request.__dict__)
        return handler_input.request_envelope.request.object_type == "LaunchRequest"

    def handle(self, handler_input):
        speech_text = "Bienvenido a grupo residencial. ¿Qué te gustaría saber?"
        return handler_input.response_builder.speak(speech_text).ask(speech_text).response

class GetExtensionIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        print("Request object:", handler_input.request_envelope.request.__dict__)
        return (handler_input.request_envelope.request.object_type == "IntentRequest" and
                handler_input.request_envelope.request.intent.name == "GetExtensionIntent")

    def handle(self, handler_input):
        slots = handler_input.request_envelope.request.intent.slots
        employee_slot = slots.get("EmployeeName")
        employee_name = employee_slot.value.lower() if employee_slot and employee_slot.value else None
        
        if not employee_name:
            speech_text = "Por favor, dime el nombre del colaborador cuya extensión deseas consultar."
            return handler_input.response_builder.speak(speech_text).ask(speech_text).response

        employee = employees.EMPLOYEES.get(employee_name)
        if employee:
            phone = employee.get('Extensión', 'No disponible')
            speech_text = f"La extensión es {phone}."
        else:
            speech_text = f"No encontré la extensión para {employee_name.capitalize()}. Por favor, verifica el nombre."
            
        return handler_input.response_builder.speak(speech_text).ask("¿Te gustaría saber otra entensión?").response
class GetEmailIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        print("Request object:", handler_input.request_envelope.request.__dict__)
        return (handler_input.request_envelope.request.object_type == "IntentRequest" and
                handler_input.request_envelope.request.intent.name == "GetEmailIntent")

    def handle(self, handler_input):
        slots = handler_input.request_envelope.request.intent.slots
        employee_slot = slots.get("EmployeeName")
        employee_name = employee_slot.value.lower() if employee_slot and employee_slot.value else None
        
        if not employee_name:
            speech_text = "Por favor, dime el nombre del colaborador cuyo correo deseas consultar."
            return handler_input.response_builder.speak(speech_text).ask(speech_text).response

        employee = employees.EMPLOYEES.get(employee_name)
        if employee:
            email = employee.get('email', 'No disponible')
            speech_text = f"El correo es {email}."
        else:
            speech_text = f"No encontré el correo para {employee_name.capitalize()}. Por favor, verifica el nombre."

        return handler_input.response_builder.speak(speech_text).ask("¿Te gustaría saber otro correo?").response
class CatchAllExceptionHandler(AbstractExceptionHandler):
    def can_handle(self, handler_input, exception):
        return True

    def handle(self, handler_input, exception):
        print("Error:", str(exception))
        print("Request:", handler_input.request_envelope.__dict__)
        speech_text = f"Lo siento, ocurrió un error: {str(exception)}. Por favor, intenta de nuevo."
        return handler_input.response_builder.speak(speech_text).ask(speech_text).response
class CancelAndStopIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return (is_request_type("IntentRequest")(handler_input) and
                (is_intent_name("AMAZON.CancelIntent")(handler_input) or
                 is_intent_name("AMAZON.StopIntent")(handler_input)))

    def handle(self, handler_input):
        speech_text = "¡Adiós!"
        return handler_input.response_builder.speak(speech_text).set_should_end_session(True).response

class HelpIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return (is_request_type("IntentRequest")(handler_input) and
                is_intent_name("AMAZON.HelpIntent")(handler_input))

    def handle(self, handler_input):
        speech_text = "Puedes pedirme la extensión o el correo de un colaborador. Por ejemplo, di 'cuál es la extensión de Juan Pérez' o 'dime el correo de María García'."
        return handler_input.response_builder.speak(speech_text).ask(speech_text).response

class NavigateHomeIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return (is_request_type("IntentRequest")(handler_input) and
                is_intent_name("AMAZON.NavigateHomeIntent")(handler_input))

    def handle(self, handler_input):
        speech_text = "Bienvenido a grupo residencial. ¿Qué te gustaría saber?"
        return handler_input.response_builder.speak(speech_text).ask(speech_text).response

# Add to SkillBuilder


sb = SkillBuilder()
sb.add_request_handler(CancelAndStopIntentHandler())
sb.add_request_handler(HelpIntentHandler())
sb.add_request_handler(NavigateHomeIntentHandler())
sb.add_request_handler(LaunchRequestHandler())
sb.add_request_handler(GetExtensionIntentHandler())
sb.add_request_handler(GetEmailIntentHandler())
sb.add_exception_handler(CatchAllExceptionHandler())

lambda_handler = sb.lambda_handler()